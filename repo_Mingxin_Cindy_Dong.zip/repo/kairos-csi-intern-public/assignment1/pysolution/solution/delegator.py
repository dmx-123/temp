import numpy as np

class Delegator:
    def __init__(self, P):
        """:param P: Square list of lists representing transition probabilities. Rows sum to 1.
        """
        self.P = np.array(P, dtype=float)
        self.best = None
        self.worst = None

    def delegate(self):
        """For each state, we solve for E(expected steps) from the equation:
            E(j) = 1 + sum_{k not in A} P[j][k] * E(k)
            where A is the set of absorbing states.
        """
        n = len(self.P)

        # determine the vented zones
        vented = set()
        for j, row in enumerate(self.P):
            if abs(row[j] - 1.0) < 1e-8 and abs(sum(row) - 1.0) < 1e-8:
                vented.add(j)

        candidate_scores = {}
        # only consider candidate zones that are not already vented
        for candidate in range(n):
            if candidate in vented:
                continue
            
            # for a given candidate, the absorbing states become:
            # (1) the candidate zone itself and (2) any zones already vented.
            absorbing = set(vented)
            absorbing.add(candidate)
            non_absorbing = [j for j in range(n) if j not in absorbing]

            E = [0.0] * n
            
            if non_absorbing:
                m = len(non_absorbing) 
                A_matrix = np.zeros((m, m), dtype=float)
                b_vector = np.ones(m, dtype=float)

                for i_idx, j in enumerate(non_absorbing):
                    for k_idx, k in enumerate(non_absorbing):
                        # delta(j,k) - P[j][k]
                        A_matrix[i_idx, k_idx] = (1.0 if j == k else 0.0) - self.P[j][k]
                # solve the linear problem
                E_vals = np.linalg.solve(A_matrix, b_vector)
                for idx, j in enumerate(non_absorbing):
                    E[j] = E_vals[idx]
            # for absorbing states E remains 0

            total_transitions = sum(round(val) for val in E)
            candidate_scores[candidate] = total_transitions

        # ensure at least 1 candidate is found
        if not candidate_scores:
            self.best = (None, None)
            self.worst = (None, None)

        # choose the best candidate
        best_candidate = min(candidate_scores.items(), key=lambda x: (x[1], x[0]))[0]
        # choose the worst candidate
        worst_candidate = max(candidate_scores.items(), key=lambda x: (x[1], x[0]))[0]

        self.best = (best_candidate, candidate_scores[best_candidate])
        self.worst = (worst_candidate, candidate_scores[worst_candidate])




