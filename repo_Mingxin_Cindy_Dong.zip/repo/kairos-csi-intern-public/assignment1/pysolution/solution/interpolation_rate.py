import numpy as np
from scipy.interpolate import interp1d
from pycsione.rate_constant import RateConstant
from pycsione.exception import PYCSIException

class InterpolationRate(RateConstant):
    
    def __init__(self, points:list, T):

        if not isinstance(points, list):
            raise PYCSIException("Invalid input: the input points shall be a list of (T, k) tuples.")

        # Filter out invalid points
        valid_points = [p for p in points if isinstance(p, tuple) and len(p)==2 and all(isinstance(x, (float, float)) for x in p)]
        if not valid_points:
            raise PYCSIException("No valid (T, k) tuples found in input data.")

        super().__init__() # not sure about this...
       
        # Ensure points are being sorted by temperature 
        self.points = sorted(valid_points)

        # Unpacking
        self.temperatures, self.rate_constants = zip(*self.points)
        
        if len(set(self.temperatures)) != len(self.temperatures):
            raise PYCSIException("Duplicate tempeature values found in input data.")

        # Process data for interpolation
        tempT = np.array(self.temperatures)
        self.T = 1/tempT
        tempk = np.array(self.rate_constants)
        self.k = np.log(tempk)

        # Creating an interpolation function
        self.interpolator = interp1d(self.T, self.k, kind='linear', fill_value="extrapolate")

    def __call__(self, T):
        """Returns the interpolated rate constant for a given temperature. 
        """
        try:
            return float(self.interpolator(T))
        except Exception as e:
            raise PYCSIException(f"Error interpolating rate constant: {e}")





