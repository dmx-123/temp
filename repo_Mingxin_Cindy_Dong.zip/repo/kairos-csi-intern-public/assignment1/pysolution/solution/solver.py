import numpy as np
from pycsione.inputs import SolverInput

class KineticSolver:
    def __init__(self, solver_input: SolverInput):
        self.T = solver_input.T
        self.initial_conditions = np.array(solver_input.initial_conditions, dtype=float)
        self.fwd_rates = solver_input.fwd_rates
        self.rev_rates = solver_input.rev_rates
        self.reactions = solver_input.reactions
        self.species = solver_input.species

    def reaction_rate(self, concentrations, t):
        """Compute the reaction rate based on current concentrations."""
        T = self.T(t)
        k_f = np.array([kf(T) for kf in self.fwd_rates])
        k_r = np.array([kr(T) for kr in self.rev_rates])
        
        # initialize reaction rates
        reaction_rates = np.zeros(len(self.species))
       
        # loop through reactions 
        for i, reaction in enumerate(self.reactions):
            reactants, products = reaction.split(" <=> ")
            reactant_indices = [self.species.index(r) for r in reactants.split()]
            product_indices = [self.species.index(p) for p in products.split()]
            
            # compute forward and reverse rates
            forward_rate = k_f[i] * np.prod(concentrations[reactant_indices])
            reverse_rate = k_r[i] * np.prod(concentrations[product_indices])
            
            # update net reaction rates
            for idx in reactant_indices:
                reaction_rates[idx] -= forward_rate    # reactants consumed
                reaction_rates[idx] += reverse_rate    # reactants regenerated
            for idx in product_indices:
                reaction_rates[idx] += forward_rate    # products generated
                reaction_rates[idx] -= reverse_rate    # products consumed

        return reaction_rates

    def solve(self, final_time:float, dt:float):
        """use runge-kutta 4th order method to solve this ode"""
        num_steps = int(np.ceil(final_time / dt))
        num_species = len(self.species)

        # initialize concentration array
        concentrations = np.zeros((num_steps + 1, num_species))    # rows = timesteps, columns = species
        concentrations[0, :] = self.initial_conditions

        # looping
        for step in range(num_steps):
            t = step * dt
            y = concentrations[step, :]

            # apply RK4 method, compute intermediate steps
            k1 = self.reaction_rate(y, t)
            k2 = self.reaction_rate(y + 0.5 * dt * k1, t + 0.5 * dt)
            k3 = self.reaction_rate(y + 0.5 * dt * k2, t + 0.5 *dt)
            k4 = self.reaction_rate(y + dt * k3, t + dt)

            # update concentrations using RK4 formulat
            concentrations[step + 1, :] = y + dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6

        return concentrations[-1, :].tolist()


