from solution import MY_NAME_IS
print(MY_NAME_IS)
from solution import InterpolationRate

from solution import KineticSolver
from solution import Delegator

P = [[0, 0.25, 0.75, 0],
     [0.25, 0, 0.75, 0],
     [0.5, 0.5, 0, 0],
     [0, 0, 0, 1]]

a = Delegator(P)
a.delegate()

print(a.best)
print(a.worst)
